package Cooking;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.cg.bean.CookingFactory;


import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class CookingStepDefinition {
	private WebDriver driver;
	private CookingFactory cookingfactory;
	boolean t;// to check whether there is text on the registration page
	boolean p;// to check whether there is text on the message page
	@Before
	public void connection() {
		String abc = "D:\\Desktop stuff\\BDD Module4\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", abc);
		driver = new ChromeDriver();
	}
	
	
	
	
	@Given("^User in on 'Registration' page$")
	public void user_in_on_Registration_page() throws Throwable {
		//directing to registration page
	   driver.get("D:\\Practice\\Spring\\bdd\\Mpt4\\Recipe_class_registration.html");
	   cookingfactory= new CookingFactory(driver);
	   Thread.sleep(10000);
	    //throw new PendingException();
	}

	@When("^User verifies title on the page 'Online Cooking School-Taste of Home '$")
	public void user_verifies_title_on_the_page_Online_Cooking_School() throws Throwable {
		//checking whether there is text on registration page 
		List<WebElement> list = driver.findElements(By.xpath("//*[contains(text(),'" + "Online Cooking School-Taste of Home" + "')]"));
		Assert.assertTrue(list.size() > 0);
		
		{
			  t=true;
		}
	    //throw new PendingException();
	}

	@Then("^User clicks on the hyperlink 'Download our Recipe class Brochure'$")
	public void user_clicks_on_the_hyperlink_Download_our_Recipe_class_Brochure() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		if(t)
		{
			driver.findElement(By.linkText("Download our Recipe class Brochure")).click();	
		}
		Thread.sleep(15000);
	}

	@Given("^User in on 'Message' page$")
	public void user_in_on_Message_page() throws Throwable {
		 driver.get("D:\\Practice\\Spring\\bdd\\Mpt4\\msg.html");
		   cookingfactory= new CookingFactory(driver);
	  //  throw new PendingException();
	}

	@When("^User verifies text on the page 'Recipe class brochure is sent to your mail id'$")
	public void user_verifies_text_on_the_page_Recipe_class_brochure_is_sent_to_your_mail_id() throws Throwable {
		List<WebElement> list = driver.findElements(By.xpath("//*[contains(text(),'" + "Recipe class Brochure is sent to your registered mail id" + "')]"));
		Assert.assertTrue(list.size() > 0);
		{
			 p=true;
		}
	   // throw new PendingException();
	}

	@Then("^User clicks on the hyperlink 'Go back to registration'$")
	public void user_clicks_on_the_hyperlink_Go_back_to_registration() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		if(p)
		{
			driver.findElement(By.linkText("Go Back to Registration")).click();
		}
			
	}

	@When("^User enters Invalid first name$")
	public void user_enters_Invalid_first_name() throws Throwable {
	   cookingfactory.setFirstname("");
	   cookingfactory.setEnquirebutton();
	   // throw new PendingException();
	}

	@Then("^Displays'first name must be filled out'$")
	public void displays_first_name_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		String expectedMessage = "First Name must be filled out";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters Invalid last name$")
	public void user_enters_Invalid_last_name() throws Throwable {
		 cookingfactory.setFirstname("naval");
		 cookingfactory.setLastname("");
		 cookingfactory.setEnquirebutton();
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
	}

	@Then("^Displays'last name must be filled out'$")
	public void displays_last_name_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		String expectedMessage = "Last Name must be filled out";
		String actualMessage = driver.switchTo().alert().getText();
	Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters email$")
	public void user_enters_email() throws Throwable {
		cookingfactory.setFirstname("naval");
		 cookingfactory.setLastname("deep");
		 cookingfactory.setEmail("navlshri@gmail.com");
		
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
	}

	@Then("^goes for the next field$")
	public void goes_for_the_next_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@When("^User enters character data$")
	public void user_enters_character_data() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		cookingfactory.setFirstname("naval");
		 cookingfactory.setLastname("deep");
		 cookingfactory.setEmail("navlshri@gmail.com");
		 cookingfactory.setMobile("hi");
		 cookingfactory.setEnquirebutton();
	}

	@Then("^Displays'Enter numeric value'$")
	public void displays_Enter_numeric_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
String expectedMessage = "Enter Numeric Valaue";
	String actualMessage = driver.switchTo().alert().getText();
	Assert.assertEquals(expectedMessage, actualMessage);
	driver.switchTo().alert().accept();
		driver.close();

	}

	@When("^User enters wrong mobile number$")
	public void user_enters_wrong_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		cookingfactory.setFirstname("naval");
		 cookingfactory.setLastname("deep");
		 cookingfactory.setEmail("navlshri@gmail.com");
		 cookingfactory.setMobile("987456321");
		 cookingfactory.setEnquirebutton();
	}

	@Then("^Displays'Enter (\\d+) digit mobile number'$")
	public void displays_Enter_digit_mobile_number(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  // throw new PendingException();
		String expectedMessage = "Enter 10 digit Mobile number";
	String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters recipe from dropdown list$")
	public void user_enters_recipe_from_dropdown_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		cookingfactory.setFirstname("naval");
		 cookingfactory.setLastname("deep");
		 cookingfactory.setEmail("navlshri@gmail.com");
		 cookingfactory.setMobile("9874563210");
		 cookingfactory.setCategory("Non-Veg");
		 
		 
	}
	@When("^User enters city from dropdown list$")
	public void user_enters_city_from_dropdown_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		cookingfactory.setFirstname("naval");
		 cookingfactory.setLastname("deep");
		 cookingfactory.setEmail("navlshri@gmail.com");
		 cookingfactory.setMobile("9874563210");
		 cookingfactory.setCategory("Non-Veg");
		 cookingfactory.setCity("Mumbai");
		 
	}

	@When("^User enters mode of learning$")
	public void user_enters_mode_of_learning() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	    cookingfactory.setFirstname("naval");
		 cookingfactory.setLastname("deep");
		 cookingfactory.setEmail("navlshri@gmail.com");
		 cookingfactory.setMobile("9874563210");
		 cookingfactory.setCategory("Non-Veg");
		 cookingfactory.setCity("Mumbai");
		 cookingfactory.setMode("In house Training");
	}

	@When("^User enters course duration$")
	public void user_enters_course_duration() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		cookingfactory.setFirstname("naval");
		 cookingfactory.setLastname("deep");
		 cookingfactory.setEmail("navlshri@gmail.com");
		 cookingfactory.setMobile("9874563210");
		 cookingfactory.setCategory("Non-Veg");
		 cookingfactory.setCity("Mumbai");
		 cookingfactory.setMode("In house Training");
		 cookingfactory.setDuration("6 months");
		 cookingfactory.setEnquirebutton();
	}

	@Then("^user clicks on 'Enquire now' button$")
	public void user_clicks_on_Enquire_now_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		String expectedMessage = "Enquiry details must be filled out";
	//	String actualMessage = driver.switchTo().alert().getText();
	//	Assert.assertEquals(expectedMessage, actualMessage);
	//	driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid enqiury details$")
	public void user_enters_invalid_enquiry_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		cookingfactory.setFirstname("naval");
		 cookingfactory.setLastname("deep");
		 cookingfactory.setEmail("navlshri@gmail.com");
		 cookingfactory.setMobile("9874563210");
		 cookingfactory.setCategory("Non-Veg");
		 cookingfactory.setMode("In house Training");
		 cookingfactory.setDuration("6 months");
		 cookingfactory.setEnquirydetails("");
		 cookingfactory.setEnquirebutton();
	}
	@Then("^Displays'Enquiry details mys be filled out'$")
	public void displays_enquiry_details_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	//	String expectedMessage = "Enquiry details must be filled out";
	//	String actualMessage = driver.switchTo().alert().getText();
	//	Assert.assertEquals(expectedMessage, actualMessage);
		//driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User clicks on 'Enquire now'$")
	public void user_clicks_on_Enquire_now() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		cookingfactory.setFirstname("naval");
		 cookingfactory.setLastname("deep");
		 cookingfactory.setEmail("navlshri@gmail.com");
		 cookingfactory.setMobile("9874563210");
		 cookingfactory.setCategory("Non-Veg");
		 cookingfactory.setMode("In house Training");
		 cookingfactory.setDuration("6 months");
		 cookingfactory.setEnquirydetails("I don't have any enquiry");
		cookingfactory.setEnquirebutton();
	}

	@Then("^displays 'thank you for submitting the onile recipe class Enquiry'$")
	public void displays_thank_you_for_submitting_the_onile_recipe_class_Enquiry() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		//String expectedMessage = "Thank you for submitting the online recipe class Enquiry";
		//String actualMessage = driver.switchTo().alert().getText();
		//Assert.assertEquals(expectedMessage, actualMessage);
	//	driver.switchTo().alert().accept();
		driver.close();
	    
	}

//	@Then("^displays 'Our local representative will contact you soon'$")
	//public void displays_Our_local_representative_will_contact_you_soon() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
		
		
	}

